import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login UI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
      home: const Login(),
    );
  }
}

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.immersiveSticky,
    );
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                const SizedBox(height: 50),

                // iba logo
                Image.asset(
                  'assets/images/iba.png',
                  height: 100,
                ),

                const SizedBox(height: 50),

                // quote
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: Text(
                    '"The difference between ordinary and extraordinary is that little Extra" ~Jimmy Johnson',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      color: Colors.blue,
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                // email label
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      Text(
                        'Email',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 5),

                // email text form field
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: TextFormField(
                    keyboardType: TextInputType.emailAddress,
                    maxLength: 50,
                    obscureText: false,
                    decoration: const InputDecoration(
                      hintText: 'm.aun.23084@khi.iba.edu.pk',
                      hintStyle: TextStyle(
                        color: Colors.grey,
                      ),
                      counterText: '',
                      filled: true,
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // password label
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      Text(
                        'Password',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 5),

                // password text form field
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: TextFormField(
                    keyboardType: TextInputType.visiblePassword,
                    maxLength: 20,
                    obscureText: true,
                    decoration: const InputDecoration(
                      hintText: 'Enter your password here',
                      hintStyle: TextStyle(
                        color: Colors.grey,
                      ),
                      counterText: '',
                      filled: true,
                    ),
                  ),
                ),

                // forgot password label
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {},
                        child: Text(
                          'Forgot Password?',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.red[400],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                // login button
                SizedBox(
                  width: (MediaQuery.of(context).size.width) - 50,
                  child: FilledButton(
                    onPressed: () {},
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.blue[800],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 25.0,
                        // horizontal: 130,
                      ),
                      child: Text(
                        'Login',
                        style: TextStyle(
                          color: Colors.grey[50],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                // or continue with
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Row(
                    children: const [
                      Expanded(
                        child: Divider(
                          thickness: 0.5,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10.0),
                        child: Text(
                          'Or continue with',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                      Expanded(
                        child: Divider(
                          thickness: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 5),

                // outlook & linkedIn signin buttons
                ButtonBar(
                  alignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      iconSize: 45.0,
                      onPressed: () {},
                      icon: Image.asset(
                        'assets/images/outlook.png',
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      iconSize: 45.0,
                      icon: Image.asset(
                        'assets/images/linkedin.png',
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 45),

                // not a student? apply now
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'Not a student?',
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text(
                        'Apply now',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
